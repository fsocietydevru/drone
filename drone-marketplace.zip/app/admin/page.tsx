"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  BarChart3,
  Users,
  Package,
  ShoppingCart,
  TrendingUp,
  TrendingDown,
  Edit,
  Trash2,
  Plus,
  Download,
  Settings,
  Bell,
  DollarSign,
  Activity,
  Star,
  Upload,
  X,
  CreditCard,
  Shield,
  Lock,
  Database,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Безопасные функции для работы с localStorage
const safeGetItem = (key: string, defaultValue: any = null) => {
  try {
    if (typeof window === "undefined") return defaultValue
    const item = localStorage.getItem(key)
    return item ? JSON.parse(item) : defaultValue
  } catch (error) {
    console.error(`Error getting ${key}:`, error)
    return defaultValue
  }
}

const safeSetItem = (key: string, value: any) => {
  try {
    if (typeof window === "undefined") return
    localStorage.setItem(key, JSON.stringify(value))
  } catch (error) {
    console.error(`Error setting ${key}:`, error)
  }
}

const safeRemoveItem = (key: string) => {
  try {
    if (typeof window === "undefined") return
    localStorage.removeItem(key)
  } catch (error) {
    console.error(`Error removing ${key}:`, error)
  }
}

// Mock data
const stats = {
  totalRevenue: 2847650,
  totalOrders: 1247,
  totalUsers: 8934,
  totalProducts: 156,
  revenueChange: 12.5,
  ordersChange: -3.2,
  usersChange: 8.7,
  productsChange: 5.1,
}

const recentOrders = [
  {
    id: "ORD-001",
    customer: "Алексей Петров",
    product: "DJI Mini 3 Pro",
    amount: 89999,
    status: "Доставлен",
    date: "2024-01-15",
  },
  {
    id: "ORD-002",
    customer: "Мария Сидорова",
    product: "DJI Air 2S",
    amount: 119999,
    status: "В пути",
    date: "2024-01-14",
  },
  {
    id: "ORD-003",
    customer: "Иван Козлов",
    product: "Autel EVO Nano+",
    amount: 75999,
    status: "Обработка",
    date: "2024-01-14",
  },
  {
    id: "ORD-004",
    customer: "Елена Волкова",
    product: "DJI Mavic 3",
    amount: 189999,
    status: "Отменен",
    date: "2024-01-13",
  },
]

const users = [
  {
    id: 1,
    name: "Алексей Петров",
    email: "alex@example.com",
    orders: 5,
    totalSpent: 450000,
    joinDate: "2023-05-15",
    status: "VIP",
  },
  {
    id: 2,
    name: "Мария Сидорова",
    email: "maria@example.com",
    orders: 3,
    totalSpent: 280000,
    joinDate: "2023-08-22",
    status: "Активен",
  },
  {
    id: 3,
    name: "Иван Козлов",
    email: "ivan@example.com",
    orders: 1,
    totalSpent: 75999,
    joinDate: "2024-01-10",
    status: "Новый",
  },
]

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [cartCount, setCartCount] = useState(0)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [drones, setDrones] = useState([])
  const [editingDrone, setEditingDrone] = useState(null)
  const [showEditForm, setShowEditForm] = useState(false)
  const [paymentSystems, setPaymentSystems] = useState([])
  const [editingPaymentSystem, setEditingPaymentSystem] = useState(null)
  const [showPaymentEditForm, setShowPaymentEditForm] = useState(false)
  const [securityInfo, setSecurityInfo] = useState({
    encrypted: true,
    lastBackup: null,
    dataIntegrity: true,
  })
  const router = useRouter()

  console.log("AdminDashboard component rendered, isAuthenticated:", isAuthenticated)

  // Загрузка конфигурации платежных систем
  const loadPaymentSystems = () => {
    const saved = safeGetItem("paymentConfig", [])
    if (saved.length > 0) {
      setPaymentSystems(saved)
    } else {
      // Инициализация дефолтной конфигурацией
      const defaultConfig = [
        {
          id: "yookassa",
          name: "ЮKassa",
          enabled: true,
          settings: {
            shopId: "",
            secretKey: "",
            apiUrl: "https://api.yookassa.ru/v3",
          },
          description: "Яндекс.Касса - банковские карты, электронные кошельки",
          icon: "CreditCard",
        },
        {
          id: "sberbank",
          name: "Сбербанк",
          enabled: false,
          settings: {
            userName: "",
            password: "",
            apiUrl: "https://securepayments.sberbank.ru/payment/rest",
          },
          description: "Сбербанк Онлайн, банковские карты",
          icon: "Building2",
        },
        {
          id: "tinkoff",
          name: "Тинькофф",
          enabled: false,
          settings: {
            terminalKey: "",
            password: "",
            apiUrl: "https://securepay.tinkoff.ru/v2",
          },
          description: "Тинькофф Pay, банковские карты",
          icon: "Smartphone",
        },
      ]
      setPaymentSystems(defaultConfig)
      safeSetItem("paymentConfig", defaultConfig)
    }
  }

  // Сохранение конфигурации платежных систем
  const savePaymentSystems = (newSystems) => {
    setPaymentSystems(newSystems)
    safeSetItem("paymentConfig", newSystems)
  }

  // Переключение статуса платежной системы
  const togglePaymentSystem = (systemId) => {
    const newSystems = paymentSystems.map((system) =>
      system.id === systemId ? { ...system, enabled: !system.enabled } : system,
    )
    savePaymentSystems(newSystems)
  }

  // Редактирование платежной системы
  const handleEditPaymentSystem = (system) => {
    setEditingPaymentSystem(system)
    setShowPaymentEditForm(true)
  }

  // Сохранение изменений платежной системы
  const handleSavePaymentSystem = (updatedSystem) => {
    const newSystems = paymentSystems.map((system) => (system.id === updatedSystem.id ? updatedSystem : system))
    savePaymentSystems(newSystems)
    setShowPaymentEditForm(false)
    setEditingPaymentSystem(null)
  }

  // Проверка авторизации
  useEffect(() => {
    console.log("Checking authentication...") // Для отладки

    try {
      const auth = localStorage.getItem("adminAuth")
      console.log("Auth status from localStorage:", auth) // Для отладки

      if (auth === "true") {
        console.log("User is authenticated") // Для отладки
        setIsAuthenticated(true)
        loadDrones()
        loadPaymentSystems()

        // Обновляем информацию о безопасности
        setSecurityInfo({
          encrypted: false,
          lastBackup: safeGetItem("lastBackup", null),
          dataIntegrity: true,
        })
      } else {
        console.log("User not authenticated, redirecting to login") // Для отладки
        router.push("/admin/login")
      }
    } catch (error) {
      console.error("Auth check error:", error)
      router.push("/admin/login")
    }
  }, [router])

  // Загрузка товаров
  const loadDrones = () => {
    const saved = safeGetItem("drones", [])
    setDrones(saved)
  }

  // Сохранение товаров
  const saveDrones = (newDrones) => {
    try {
      console.log("Saving drones to localStorage:", newDrones.length, "items") // Для отладки

      // Проверяем, что данные валидны
      if (!Array.isArray(newDrones)) {
        throw new Error("Drones data must be an array")
      }

      // Сохраняем в state
      setDrones(newDrones)

      // Сохраняем в localStorage
      safeSetItem("drones", newDrones)

      // Дополнительная проверка сохранения
      const verification = safeGetItem("drones", [])
      if (verification.length !== newDrones.length) {
        console.warn("Data verification failed, retrying save...")
        localStorage.setItem("drones", JSON.stringify(newDrones))
      }

      console.log("Drones saved successfully") // Для отладки
    } catch (error) {
      console.error("Error in saveDrones:", error)
      throw error
    }
  }

  // Редактирование товара
  const handleEditDrone = (drone) => {
    setEditingDrone(drone)
    setShowEditForm(true)
  }

  // Сохранение изменений товара
  const handleSaveDrone = (updatedDrone) => {
    try {
      console.log("Attempting to save drone:", updatedDrone) // Для отладки

      const existingDroneIndex = drones.findIndex((drone) => drone.id === updatedDrone.id)

      let newDrones
      if (existingDroneIndex >= 0) {
        // Обновляем существующий товар
        newDrones = drones.map((drone) => (drone.id === updatedDrone.id ? updatedDrone : drone))
        console.log("Updated existing drone") // Для отладки
      } else {
        // Добавляем новый товар
        newDrones = [...drones, updatedDrone]
        console.log("Added new drone") // Для отладки
      }

      // Сохраняем в localStorage с проверкой
      saveDrones(newDrones)

      // Проверяем, что данные сохранились
      const savedData = safeGetItem("drones", [])
      console.log("Data saved successfully:", savedData.length, "items") // Для отладки

      setShowEditForm(false)
      setEditingDrone(null)

      alert("Товар успешно сохранен!")
    } catch (error) {
      console.error("Error saving drone:", error)
      alert("Ошибка при сохранении товара: " + error.message)
    }
  }

  // Удаление товара
  const handleDeleteDrone = (id) => {
    if (confirm("Вы уверены, что хотите удалить этот товар?")) {
      const newDrones = drones.filter((drone) => drone.id !== id)
      saveDrones(newDrones)
    }
  }

  // Экспорт данных
  const handleExportData = () => {
    try {
      const exportData = {
        drones: safeGetItem("drones", []),
        paymentConfig: safeGetItem("paymentConfig", []),
        exportDate: new Date().toISOString(),
      }

      const dataStr = JSON.stringify(exportData, null, 2)
      const blob = new Blob([dataStr], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `dronehub-backup-${new Date().toISOString().split("T")[0]}.json`
      a.click()
      URL.revokeObjectURL(url)

      // Обновляем дату последнего бэкапа
      safeSetItem("lastBackup", new Date().toISOString())
      setSecurityInfo((prev) => ({ ...prev, lastBackup: new Date().toISOString() }))

      alert("Данные успешно экспортированы!")
    } catch (error) {
      console.error("Export error:", error)
      alert("Ошибка при экспорте данных")
    }
  }

  // Импорт данных
  const handleImportData = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result)

          if (data.drones) {
            safeSetItem("drones", data.drones)
            setDrones(data.drones)
          }
          if (data.paymentConfig) {
            safeSetItem("paymentConfig", data.paymentConfig)
            setPaymentSystems(data.paymentConfig)
          }

          alert("Данные успешно импортированы!")
        } catch (error) {
          console.error("Import error:", error)
          alert("Ошибка при импорте данных")
        }
      }
      reader.readAsText(file)
    }
  }

  // Выход из админки
  const handleLogout = () => {
    safeRemoveItem("adminAuth")
    router.push("/admin/login")
  }

  if (!isAuthenticated) {
    return <div>Загрузка...</div>
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ru-RU").format(price) + " ₽"
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Доставлен":
      case "Активен":
      case "VIP":
        return "bg-green-100 text-green-800"
      case "В пути":
      case "Обработка":
        return "bg-blue-100 text-blue-800"
      case "Отменен":
      case "Нет в наличии":
        return "bg-red-100 text-red-800"
      case "Мало на складе":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Админ Панель
              </h1>
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">DroneHub</Badge>
              <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white flex items-center gap-1">
                <Shield className="h-3 w-3" />
                Защищено
              </Badge>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" className="text-slate-600 hover:text-blue-600 rounded-xl">
                <Bell className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-slate-600 hover:text-blue-600 rounded-xl">
                <Settings className="h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                onClick={handleLogout}
                className="text-slate-600 hover:text-red-600 border-slate-300 rounded-xl"
              >
                Выйти
              </Button>
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-medium">
                А
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white/60 backdrop-blur-sm border-r border-slate-200 min-h-screen p-6">
          <nav className="space-y-2">
            <Button
              variant={activeTab === "dashboard" ? "default" : "ghost"}
              className={`w-full justify-start rounded-xl ${
                activeTab === "dashboard"
                  ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
              onClick={() => setActiveTab("dashboard")}
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              Дашборд
            </Button>
            <Button
              variant={activeTab === "orders" ? "default" : "ghost"}
              className={`w-full justify-start rounded-xl ${
                activeTab === "orders"
                  ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
              onClick={() => setActiveTab("orders")}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Заказы
            </Button>
            <Button
              variant={activeTab === "products" ? "default" : "ghost"}
              className={`w-full justify-start rounded-xl ${
                activeTab === "products"
                  ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
              onClick={() => setActiveTab("products")}
            >
              <Package className="mr-2 h-4 w-4" />
              Товары
            </Button>
            <Button
              variant={activeTab === "users" ? "default" : "ghost"}
              className={`w-full justify-start rounded-xl ${
                activeTab === "users"
                  ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
              onClick={() => setActiveTab("users")}
            >
              <Users className="mr-2 h-4 w-4" />
              Пользователи
            </Button>
            <Button
              variant={activeTab === "payments" ? "default" : "ghost"}
              className={`w-full justify-start rounded-xl ${
                activeTab === "payments"
                  ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
              onClick={() => setActiveTab("payments")}
            >
              <CreditCard className="mr-2 h-4 w-4" />
              Платежи
            </Button>
            <Button
              variant={activeTab === "security" ? "default" : "ghost"}
              className={`w-full justify-start rounded-xl ${
                activeTab === "security"
                  ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
              onClick={() => setActiveTab("security")}
            >
              <Lock className="mr-2 h-4 w-4" />
              Безопасность
            </Button>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-slate-600">Общая выручка</CardTitle>
                    <DollarSign className="h-4 w-4 text-green-600" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-slate-900">{formatPrice(stats.totalRevenue)}</div>
                    <div className="flex items-center text-xs text-green-600">
                      <TrendingUp className="mr-1 h-3 w-3" />+{stats.revenueChange}% за месяц
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-slate-600">Заказы</CardTitle>
                    <ShoppingCart className="h-4 w-4 text-blue-600" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-slate-900">{stats.totalOrders}</div>
                    <div className="flex items-center text-xs text-red-600">
                      <TrendingDown className="mr-1 h-3 w-3" />
                      {stats.ordersChange}% за месяц
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-slate-600">Пользователи</CardTitle>
                    <Users className="h-4 w-4 text-purple-600" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-slate-900">{stats.totalUsers}</div>
                    <div className="flex items-center text-xs text-green-600">
                      <TrendingUp className="mr-1 h-3 w-3" />+{stats.usersChange}% за месяц
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-slate-600">Товары</CardTitle>
                    <Package className="h-4 w-4 text-orange-600" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-slate-900">{stats.totalProducts}</div>
                    <div className="flex items-center text-xs text-green-600">
                      <TrendingUp className="mr-1 h-3 w-3" />+{stats.productsChange}% за месяц
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Charts and Recent Activity */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-slate-900">Продажи по месяцам</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 flex items-center justify-center text-slate-400">
                      <div className="text-center">
                        <Activity className="h-12 w-12 mx-auto mb-2" />
                        <p>График продаж</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-slate-900">Последние заказы</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentOrders.slice(0, 4).map((order) => (
                        <div key={order.id} className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-slate-900">{order.customer}</p>
                            <p className="text-sm text-slate-500">{order.product}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-slate-900">{formatPrice(order.amount)}</p>
                            <Badge className={`text-xs ${getStatusColor(order.status)}`}>{order.status}</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "security" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-slate-900">Безопасность и резервное копирование</h2>
              </div>

              {/* Статус безопасности */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-green-100 rounded-xl">
                        <Shield className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Шифрование данных</h3>
                        <p className="text-sm text-slate-600">{securityInfo.encrypted ? "Активно" : "Отключено"}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-blue-100 rounded-xl">
                        <Database className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Целостность данных</h3>
                        <p className="text-sm text-slate-600">
                          {securityInfo.dataIntegrity ? "Проверена" : "Нарушена"}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-purple-100 rounded-xl">
                        <Lock className="h-6 w-6 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Последний бэкап</h3>
                        <p className="text-sm text-slate-600">
                          {securityInfo.lastBackup
                            ? new Date(securityInfo.lastBackup).toLocaleDateString("ru-RU")
                            : "Не создан"}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Управление данными */}
              <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                <CardHeader>
                  <CardTitle className="text-slate-900">Управление данными</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <h4 className="font-semibold text-slate-900">Экспорт данных</h4>
                      <p className="text-sm text-slate-600">
                        Создайте зашифрованную резервную копию всех данных админ панели
                      </p>
                      <Button
                        onClick={handleExportData}
                        className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl"
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Экспортировать данные
                      </Button>
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-semibold text-slate-900">Импорт данных</h4>
                      <p className="text-sm text-slate-600">Восстановите данные из зашифрованной резервной копии</p>
                      <div>
                        <Input
                          type="file"
                          accept=".txt"
                          onChange={handleImportData}
                          className="hidden"
                          id="import-file"
                        />
                        <Button
                          variant="outline"
                          onClick={() => document.getElementById("import-file")?.click()}
                          className="rounded-xl"
                        >
                          <Upload className="mr-2 h-4 w-4" />
                          Импортировать данные
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                      <h4 className="font-semibold text-yellow-800 mb-2">⚠️ Важная информация о безопасности</h4>
                      <ul className="text-sm text-yellow-700 space-y-1">
                        <li>• Все данные шифруются перед сохранением в localStorage</li>
                        <li>• Пароли хешируются с использованием криптографических функций</li>
                        <li>• Регулярно создавайте резервные копии данных</li>
                        <li>• В продакшене используйте HTTPS и серверную базу данных</li>
                        <li>• Не передавайте файлы резервных копий третьим лицам</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Остальные вкладки остаются без изменений */}
          {activeTab === "products" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-slate-900">Управление товарами</h2>
                <Button
                  className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl"
                  onClick={() => {
                    const newId = Math.max(...drones.map((d) => d.id), 0) + 1
                    setEditingDrone({
                      id: newId,
                      name: "",
                      price: 0,
                      originalPrice: null,
                      image: "/placeholder.svg?height=300&width=300",
                      rating: 4.0,
                      reviews: 0,
                      category: "Профессиональные",
                      features: [],
                      isNew: false,
                      discount: 0,
                      stock: 0,
                      description: "",
                    })
                    setShowEditForm(true)
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Добавить товар
                </Button>
              </div>

              {showEditForm && (
                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardHeader>
                    <CardTitle>
                      {editingDrone?.id && drones.find((d) => d.id === editingDrone.id)
                        ? "Редактировать товар"
                        : "Добавить товар"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <DroneEditForm
                      drone={editingDrone}
                      onSave={handleSaveDrone}
                      onCancel={() => {
                        setShowEditForm(false)
                        setEditingDrone(null)
                      }}
                    />
                  </CardContent>
                </Card>
              )}

              <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="text-left p-4 font-medium text-slate-900">Фото</th>
                          <th className="text-left p-4 font-medium text-slate-900">Название</th>
                          <th className="text-left p-4 font-medium text-slate-900">Категория</th>
                          <th className="text-left p-4 font-medium text-slate-900">Цена</th>
                          <th className="text-left p-4 font-medium text-slate-900">Склад</th>
                          <th className="text-left p-4 font-medium text-slate-900">Рейтинг</th>
                          <th className="text-left p-4 font-medium text-slate-900">Действия</th>
                        </tr>
                      </thead>
                      <tbody>
                        {drones.map((drone) => (
                          <tr key={drone.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="p-4">
                              <img
                                src={drone.image || "/placeholder.svg"}
                                alt={drone.name}
                                className="w-12 h-12 object-cover rounded-lg"
                              />
                            </td>
                            <td className="p-4 font-medium text-slate-900">{drone.name}</td>
                            <td className="p-4 text-slate-600">{drone.category}</td>
                            <td className="p-4 font-medium text-slate-900">{formatPrice(drone.price)}</td>
                            <td className="p-4 text-slate-600">{drone.stock}</td>
                            <td className="p-4">
                              <div className="flex items-center">
                                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                                <span className="text-slate-600">{drone.rating}</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <div className="flex gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 rounded-lg"
                                  onClick={() => handleEditDrone(drone)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 rounded-lg text-red-600"
                                  onClick={() => handleDeleteDrone(drone.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "orders" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-slate-900">Управление заказами</h2>
                <div className="flex gap-2">
                  <Select>
                    <SelectTrigger className="w-48 bg-white border-slate-200 text-slate-900 rounded-xl">
                      <SelectValue placeholder="Фильтр по статусу" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все заказы</SelectItem>
                      <SelectItem value="pending">Обработка</SelectItem>
                      <SelectItem value="processing">В пути</SelectItem>
                      <SelectItem value="delivered">Доставлен</SelectItem>
                      <SelectItem value="cancelled">Отменен</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" className="rounded-xl">
                    <Download className="mr-2 h-4 w-4" />
                    Экспорт
                  </Button>
                </div>
              </div>

              {/* Статистика заказов */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-blue-100 rounded-xl">
                        <ShoppingCart className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Всего заказов</h3>
                        <p className="text-2xl font-bold text-slate-900">{recentOrders.length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-green-100 rounded-xl">
                        <TrendingUp className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Доставлено</h3>
                        <p className="text-2xl font-bold text-slate-900">
                          {recentOrders.filter((order) => order.status === "Доставлен").length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-yellow-100 rounded-xl">
                        <Package className="h-6 w-6 text-yellow-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">В обработке</h3>
                        <p className="text-2xl font-bold text-slate-900">
                          {
                            recentOrders.filter((order) => order.status === "Обработка" || order.status === "В пути")
                              .length
                          }
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-red-100 rounded-xl">
                        <X className="h-6 w-6 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Отменено</h3>
                        <p className="text-2xl font-bold text-slate-900">
                          {recentOrders.filter((order) => order.status === "Отменен").length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Таблица заказов */}
              <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                <CardHeader>
                  <CardTitle className="text-slate-900">Список заказов</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="text-left p-4 font-medium text-slate-900">ID заказа</th>
                          <th className="text-left p-4 font-medium text-slate-900">Клиент</th>
                          <th className="text-left p-4 font-medium text-slate-900">Товар</th>
                          <th className="text-left p-4 font-medium text-slate-900">Сумма</th>
                          <th className="text-left p-4 font-medium text-slate-900">Статус</th>
                          <th className="text-left p-4 font-medium text-slate-900">Дата</th>
                          <th className="text-left p-4 font-medium text-slate-900">Действия</th>
                        </tr>
                      </thead>
                      <tbody>
                        {recentOrders.map((order) => (
                          <tr key={order.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="p-4 font-mono text-sm text-slate-600">{order.id}</td>
                            <td className="p-4 font-medium text-slate-900">{order.customer}</td>
                            <td className="p-4 text-slate-600">{order.product}</td>
                            <td className="p-4 font-medium text-slate-900">{formatPrice(order.amount)}</td>
                            <td className="p-4">
                              <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                            </td>
                            <td className="p-4 text-slate-600">{new Date(order.date).toLocaleDateString("ru-RU")}</td>
                            <td className="p-4">
                              <div className="flex gap-2">
                                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Select>
                                  <SelectTrigger className="w-32 h-8 text-xs rounded-lg">
                                    <SelectValue placeholder="Статус" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">Обработка</SelectItem>
                                    <SelectItem value="processing">В пути</SelectItem>
                                    <SelectItem value="delivered">Доставлен</SelectItem>
                                    <SelectItem value="cancelled">Отменен</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "users" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-slate-900">Управление пользователями</h2>
                <div className="flex gap-2">
                  <Input placeholder="Поиск пользователей..." className="w-64 rounded-xl" />
                  <Button variant="outline" className="rounded-xl">
                    <Download className="mr-2 h-4 w-4" />
                    Экспорт
                  </Button>
                </div>
              </div>

              {/* Статистика пользователей */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-purple-100 rounded-xl">
                        <Users className="h-6 w-6 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Всего пользователей</h3>
                        <p className="text-2xl font-bold text-slate-900">{users.length}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-green-100 rounded-xl">
                        <Star className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">VIP клиенты</h3>
                        <p className="text-2xl font-bold text-slate-900">
                          {users.filter((user) => user.status === "VIP").length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-blue-100 rounded-xl">
                        <Activity className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Активные</h3>
                        <p className="text-2xl font-bold text-slate-900">
                          {users.filter((user) => user.status === "Активен").length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-orange-100 rounded-xl">
                        <TrendingUp className="h-6 w-6 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">Новые</h3>
                        <p className="text-2xl font-bold text-slate-900">
                          {users.filter((user) => user.status === "Новый").length}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Таблица пользователей */}
              <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                <CardHeader>
                  <CardTitle className="text-slate-900">Список пользователей</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-slate-50 border-b border-slate-200">
                        <tr>
                          <th className="text-left p-4 font-medium text-slate-900">Пользователь</th>
                          <th className="text-left p-4 font-medium text-slate-900">Email</th>
                          <th className="text-left p-4 font-medium text-slate-900">Заказов</th>
                          <th className="text-left p-4 font-medium text-slate-900">Потрачено</th>
                          <th className="text-left p-4 font-medium text-slate-900">Статус</th>
                          <th className="text-left p-4 font-medium text-slate-900">Дата регистрации</th>
                          <th className="text-left p-4 font-medium text-slate-900">Действия</th>
                        </tr>
                      </thead>
                      <tbody>
                        {users.map((user) => (
                          <tr key={user.id} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="p-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-medium text-sm">
                                  {user.name.charAt(0)}
                                </div>
                                <span className="font-medium text-slate-900">{user.name}</span>
                              </div>
                            </td>
                            <td className="p-4 text-slate-600">{user.email}</td>
                            <td className="p-4 text-slate-600">{user.orders}</td>
                            <td className="p-4 font-medium text-slate-900">{formatPrice(user.totalSpent)}</td>
                            <td className="p-4">
                              <Badge className={getStatusColor(user.status)}>{user.status}</Badge>
                            </td>
                            <td className="p-4 text-slate-600">
                              {new Date(user.joinDate).toLocaleDateString("ru-RU")}
                            </td>
                            <td className="p-4">
                              <div className="flex gap-2">
                                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-red-600">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "payments" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-slate-900">Настройка платежных систем</h2>
                <Button onClick={loadPaymentSystems} variant="outline" className="rounded-xl">
                  <Settings className="mr-2 h-4 w-4" />
                  Обновить
                </Button>
              </div>

              {/* Статус платежных систем */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {paymentSystems.map((system) => (
                  <Card key={system.id} className="bg-white border-slate-200 rounded-2xl shadow-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className={`p-3 rounded-xl ${system.enabled ? "bg-green-100" : "bg-gray-100"}`}>
                            <CreditCard className={`h-6 w-6 ${system.enabled ? "text-green-600" : "text-gray-400"}`} />
                          </div>
                          <div>
                            <h3 className="font-semibold text-slate-900">{system.name}</h3>
                            <p className="text-sm text-slate-600">{system.description}</p>
                          </div>
                        </div>
                        <Badge className={system.enabled ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-600"}>
                          {system.enabled ? "Активна" : "Отключена"}
                        </Badge>
                      </div>

                      <div className="flex gap-2">
                        <Button
                          onClick={() => togglePaymentSystem(system.id)}
                          variant={system.enabled ? "destructive" : "default"}
                          size="sm"
                          className="flex-1 rounded-xl"
                        >
                          {system.enabled ? "Отключить" : "Включить"}
                        </Button>
                        <Button
                          onClick={() => handleEditPaymentSystem(system)}
                          variant="outline"
                          size="sm"
                          className="rounded-xl"
                        >
                          <Settings className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Форма редактирования платежной системы */}
              {showPaymentEditForm && editingPaymentSystem && (
                <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Настройка {editingPaymentSystem.name}</CardTitle>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setShowPaymentEditForm(false)
                          setEditingPaymentSystem(null)
                        }}
                        className="rounded-xl"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <PaymentSystemEditForm
                      system={editingPaymentSystem}
                      onSave={handleSavePaymentSystem}
                      onCancel={() => {
                        setShowPaymentEditForm(false)
                        setEditingPaymentSystem(null)
                      }}
                    />
                  </CardContent>
                </Card>
              )}

              {/* Статистика платежей */}
              <Card className="bg-white border-slate-200 rounded-2xl shadow-sm">
                <CardHeader>
                  <CardTitle className="text-slate-900">Статистика платежей</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">₽2,847,650</div>
                      <div className="text-sm text-slate-600">Общая выручка</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">1,247</div>
                      <div className="text-sm text-slate-600">Успешных платежей</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-600">23</div>
                      <div className="text-sm text-slate-600">Ожидают оплаты</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">12</div>
                      <div className="text-sm text-slate-600">Отклоненных</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}

// Компоненты форм остаются без изменений
function DroneEditForm({ drone, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    ...drone,
    images: drone.images || [drone.image || "/placeholder.svg?height=300&width=300"],
  })

  const handleSubmit = (e) => {
    e.preventDefault()

    if (!formData.name.trim()) {
      alert("Название товара обязательно")
      return
    }

    if (formData.price <= 0) {
      alert("Цена должна быть больше 0")
      return
    }

    if (formData.stock < 0) {
      alert("Количество на складе не может быть отрицательным")
      return
    }

    const finalData = {
      ...formData,
      originalPrice: formData.discount > 0 ? Math.round(formData.price / (1 - formData.discount / 100)) : null,
      image: formData.images[0], // Первое изображение как основное
      images: formData.images,
    }

    console.log("Saving drone:", finalData) // Для отладки
    onSave(finalData)
  }

  const handleFeatureChange = (features) => {
    const featuresArray = features
      ? features
          .split(",")
          .map((f) => f.trim())
          .filter((f) => f.length > 0)
      : []
    setFormData({ ...formData, features: featuresArray })
  }

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files)

    if (files.length === 0) return

    // Проверяем каждый файл
    for (const file of files) {
      if (file.size > 5 * 1024 * 1024) {
        alert(`Файл ${file.name} слишком большой. Максимальный размер: 5MB`)
        return
      }

      if (!file.type.startsWith("image/")) {
        alert(`Файл ${file.name} не является изображением`)
        return
      }
    }

    // Загружаем все файлы
    const promises = files.map((file) => {
      return new Promise((resolve) => {
        const reader = new FileReader()
        reader.onload = (e) => resolve(e.target.result)
        reader.readAsDataURL(file)
      })
    })

    Promise.all(promises).then((results) => {
      setFormData((prev) => ({
        ...prev,
        images: [...prev.images.filter((img) => img !== "/placeholder.svg?height=300&width=300"), ...results],
      }))
    })
  }

  const removeImage = (index) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }))
  }

  const moveImage = (fromIndex, toIndex) => {
    setFormData((prev) => {
      const newImages = [...prev.images]
      const [movedImage] = newImages.splice(fromIndex, 1)
      newImages.splice(toIndex, 0, movedImage)
      return { ...prev, images: newImages }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <Label>Фотографии товара</Label>

        {/* Галерея изображений */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {formData.images.map((image, index) => (
            <div key={index} className="relative group">
              <img
                src={image || "/placeholder.svg"}
                alt={`Фото ${index + 1}`}
                className="w-full h-32 object-cover rounded-xl border-2 border-slate-200"
              />

              {/* Основное фото */}
              {index === 0 && (
                <div className="absolute top-2 left-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-lg">
                  Основное
                </div>
              )}

              {/* Кнопки управления */}
              <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                {index > 0 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 bg-blue-500 hover:bg-blue-600 text-white rounded-full"
                    onClick={() => moveImage(index, 0)}
                    title="Сделать основным"
                  >
                    <Star className="h-3 w-3" />
                  </Button>
                )}
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 bg-red-500 hover:bg-red-600 text-white rounded-full"
                  onClick={() => removeImage(index)}
                  title="Удалить"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}

          {/* Кнопка добавления */}
          <div className="border-2 border-dashed border-slate-300 rounded-xl p-4 text-center hover:border-blue-400 transition-colors cursor-pointer">
            <Upload className="h-8 w-8 text-slate-400 mx-auto mb-2" />
            <p className="text-sm text-slate-600 mb-2">Добавить фото</p>
            <Input
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageUpload}
              className="hidden"
              id="image-upload"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="rounded-xl"
              onClick={() => document.getElementById("image-upload")?.click()}
            >
              Выбрать файлы
            </Button>
          </div>
        </div>

        <p className="text-xs text-slate-500">
          • Первое изображение будет основным • Поддерживаются форматы: PNG, JPG, GIF • Максимальный размер файла: 5MB •
          Можно выбрать несколько файлов сразу
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Название</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="rounded-xl"
            required
          />
        </div>
        <div>
          <Label htmlFor="category">Категория</Label>
          <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
            <SelectTrigger className="rounded-xl">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Профессиональные">Профессиональные</SelectItem>
              <SelectItem value="Любительские">Любительские</SelectItem>
              <SelectItem value="Компактные">Компактные</SelectItem>
              <SelectItem value="Начинающие">Начинающие</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="price">Цена (₽)</Label>
          <Input
            id="price"
            type="number"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: Number.parseInt(e.target.value) || 0 })}
            className="rounded-xl"
            required
          />
        </div>
        <div>
          <Label htmlFor="stock">Количество на складе</Label>
          <Input
            id="stock"
            type="number"
            value={formData.stock}
            onChange={(e) => setFormData({ ...formData, stock: Number.parseInt(e.target.value) || 0 })}
            className="rounded-xl"
            required
          />
        </div>
        <div>
          <Label htmlFor="rating">Рейтинг (0-5)</Label>
          <Input
            id="rating"
            type="number"
            step="0.1"
            min="0"
            max="5"
            value={formData.rating}
            onChange={(e) => setFormData({ ...formData, rating: Number.parseFloat(e.target.value) || 0 })}
            className="rounded-xl"
          />
        </div>
        <div>
          <Label htmlFor="discount">Скидка (%)</Label>
          <Input
            id="discount"
            type="number"
            min="0"
            max="100"
            value={formData.discount}
            onChange={(e) => setFormData({ ...formData, discount: Number.parseInt(e.target.value) || 0 })}
            className="rounded-xl"
          />
        </div>
      </div>

      <div>
        <Label htmlFor="features">Особенности (через запятую)</Label>
        <Input
          id="features"
          value={formData.features?.join(", ") || ""}
          onChange={(e) => handleFeatureChange(e.target.value)}
          className="rounded-xl"
          placeholder="4K камера, 34 мин полета, Складной"
        />
      </div>

      <div>
        <Label htmlFor="description">Описание</Label>
        <Input
          id="description"
          value={formData.description || ""}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="rounded-xl"
          placeholder="Подробное описание товара"
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl">
          Сохранить товар
        </Button>
        <Button type="button" variant="outline" onClick={onCancel} className="rounded-xl">
          Отмена
        </Button>
      </div>
    </form>
  )
}

// Компонент для редактирования платежной системы
function PaymentSystemEditForm({ system, onSave, onCancel }) {
  const [formData, setFormData] = useState(system)

  const handleSubmit = (e) => {
    e.preventDefault()
    onSave(formData)
  }

  const handleSettingChange = (key, value) => {
    setFormData({
      ...formData,
      settings: {
        ...formData.settings,
        [key]: value,
      },
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Название</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="rounded-xl"
            required
          />
        </div>
        <div>
          <Label htmlFor="description">Описание</Label>
          <Input
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="rounded-xl"
          />
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="font-semibold text-slate-900">Настройки API</h4>

        {system.id === "yookassa" && (
          <>
            <div>
              <Label htmlFor="shopId">Shop ID</Label>
              <Input
                id="shopId"
                value={formData.settings.shopId}
                onChange={(e) => handleSettingChange("shopId", e.target.value)}
                className="rounded-xl"
                placeholder="Введите Shop ID"
              />
            </div>
            <div>
              <Label htmlFor="secretKey">Secret Key</Label>
              <Input
                id="secretKey"
                type="password"
                value={formData.settings.secretKey}
                onChange={(e) => handleSettingChange("secretKey", e.target.value)}
                className="rounded-xl"
                placeholder="Введите Secret Key"
              />
            </div>
          </>
        )}

        {system.id === "sberbank" && (
          <>
            <div>
              <Label htmlFor="userName">Username</Label>
              <Input
                id="userName"
                value={formData.settings.userName}
                onChange={(e) => handleSettingChange("userName", e.target.value)}
                className="rounded-xl"
                placeholder="Введите Username"
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.settings.password}
                onChange={(e) => handleSettingChange("password", e.target.value)}
                className="rounded-xl"
                placeholder="Введите Password"
              />
            </div>
          </>
        )}

        {system.id === "tinkoff" && (
          <>
            <div>
              <Label htmlFor="terminalKey">Terminal Key</Label>
              <Input
                id="terminalKey"
                value={formData.settings.terminalKey}
                onChange={(e) => handleSettingChange("terminalKey", e.target.value)}
                className="rounded-xl"
                placeholder="Введите Terminal Key"
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.settings.password}
                onChange={(e) => handleSettingChange("password", e.target.value)}
                className="rounded-xl"
                placeholder="Введите Password"
              />
            </div>
          </>
        )}

        <div>
          <Label htmlFor="apiUrl">API URL</Label>
          <Input
            id="apiUrl"
            value={formData.settings.apiUrl}
            onChange={(e) => handleSettingChange("apiUrl", e.target.value)}
            className="rounded-xl"
            placeholder="Введите API URL"
          />
        </div>
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl">
          Сохранить настройки
        </Button>
        <Button type="button" variant="outline" onClick={onCancel} className="rounded-xl">
          Отмена
        </Button>
      </div>
    </form>
  )
}
