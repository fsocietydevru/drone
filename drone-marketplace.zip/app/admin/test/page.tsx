"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function AdminTest() {
  const [authStatus, setAuthStatus] = useState("")
  const [localStorageData, setLocalStorageData] = useState({})

  useEffect(() => {
    // Проверяем localStorage
    const auth = localStorage.getItem("adminAuth")
    setAuthStatus(auth || "не установлен")

    // Получаем все данные из localStorage
    const data = {}
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i)
      if (key) {
        data[key] = localStorage.getItem(key)
      }
    }
    setLocalStorageData(data)
  }, [])

  const setAuth = () => {
    localStorage.setItem("adminAuth", "true")
    setAuthStatus("true")
    alert("Авторизация установлена!")
  }

  const clearAuth = () => {
    localStorage.removeItem("adminAuth")
    setAuthStatus("не установлен")
    alert("Авторизация очищена!")
  }

  const clearAll = () => {
    localStorage.clear()
    setLocalStorageData({})
    setAuthStatus("не установлен")
    alert("Все данные очищены!")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-8">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>Тестирование админ панели</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-2">Статус авторизации</h3>
            <p className="text-slate-600">
              adminAuth: <strong>{authStatus}</strong>
            </p>
          </div>

          <div className="flex gap-4">
            <Button onClick={setAuth} className="bg-green-600 hover:bg-green-700">
              Установить авторизацию
            </Button>
            <Button onClick={clearAuth} variant="outline">
              Очистить авторизацию
            </Button>
            <Button onClick={clearAll} variant="destructive">
              Очистить все данные
            </Button>
            <Button onClick={() => (window.location.href = "/admin")} className="bg-blue-600 hover:bg-blue-700">
              Перейти в админ панель
            </Button>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-2">Данные localStorage</h3>
            <pre className="bg-slate-100 p-4 rounded-lg text-sm overflow-auto">
              {JSON.stringify(localStorageData, null, 2)}
            </pre>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 className="font-semibold text-yellow-800 mb-2">Инструкции для отладки:</h4>
            <ol className="text-sm text-yellow-700 space-y-1">
              <li>1. Нажмите "Установить авторизацию"</li>
              <li>2. Нажмите "Перейти в админ панель"</li>
              <li>3. Если не работает, откройте консоль браузера (F12)</li>
              <li>4. Посмотрите на сообщения в консоли</li>
              <li>5. Если нужно, нажмите "Очистить все данные" и попробуйте снова</li>
            </ol>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
