"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { CheckCircle, Package, ArrowRight, Home } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function PaymentSuccess() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get("orderId")
  const [orderData, setOrderData] = useState(null)

  useEffect(() => {
    if (orderId) {
      const savedOrder = localStorage.getItem(`order-${orderId}`)
      if (savedOrder) {
        const order = JSON.parse(savedOrder)
        setOrderData(order)

        // Обновляем статус заказа
        localStorage.setItem(
          `order-${orderId}`,
          JSON.stringify({
            ...order,
            status: "paid",
          }),
        )
      }
    }
  }, [orderId])

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ru-RU").format(price) + " ₽"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-white rounded-2xl shadow-xl">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-slate-900">Оплата прошла успешно!</CardTitle>
          <p className="text-slate-600 mt-2">Спасибо за покупку! Ваш заказ принят в обработку.</p>
        </CardHeader>

        <CardContent className="space-y-6">
          {orderData && (
            <>
              <div className="bg-slate-50 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Package className="h-5 w-5 text-blue-600" />
                  <h3 className="font-semibold text-slate-900">Детали заказа #{orderId}</h3>
                </div>

                <div className="space-y-2">
                  {orderData.items.map((item) => (
                    <div key={item.id} className="flex justify-between items-center">
                      <span className="text-slate-600">
                        {item.name} × {item.quantity}
                      </span>
                      <span className="font-medium">{formatPrice(item.price * item.quantity)}</span>
                    </div>
                  ))}
                  <div className="border-t pt-2 mt-2">
                    <div className="flex justify-between items-center font-bold text-lg">
                      <span>Итого:</span>
                      <span className="text-green-600">{formatPrice(orderData.total)}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 rounded-xl p-4">
                <h4 className="font-semibold text-slate-900 mb-2">Что дальше?</h4>
                <ul className="space-y-2 text-sm text-slate-600">
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-blue-600" />
                    Мы отправили подтверждение на {orderData.customerData.email}
                  </li>
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-blue-600" />
                    Заказ будет собран и отправлен в течение 1-2 рабочих дней
                  </li>
                  <li className="flex items-center gap-2">
                    <ArrowRight className="h-4 w-4 text-blue-600" />
                    Трек-номер для отслеживания придет SMS на {orderData.customerData.phone}
                  </li>
                </ul>
              </div>
            </>
          )}

          <div className="flex gap-3">
            <Link href="/" className="flex-1">
              <Button variant="outline" className="w-full rounded-xl">
                <Home className="mr-2 h-4 w-4" />
                На главную
              </Button>
            </Link>
            <Button className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl">
              Отследить заказ
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
