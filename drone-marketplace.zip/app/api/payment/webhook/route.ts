import { type NextRequest, NextResponse } from "next/server"

// Webhook для обработки уведомлений о статусе платежа
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const paymentSystem = request.nextUrl.searchParams.get("system")

    console.log(`Webhook from ${paymentSystem}:`, body)

    // Обработка webhook от YooKassa
    if (paymentSystem === "yookassa") {
      const { object: payment } = body

      if (payment && payment.status === "succeeded") {
        // Платеж успешно завершен
        const orderId = payment.metadata?.order_id

        // Обновляем статус заказа в базе данных
        console.log(`Payment succeeded for order: ${orderId}`)

        // Здесь можно отправить email, обновить статус заказа и т.д.
      }
    }

    // Обработка webhook от Сбербанка
    if (paymentSystem === "sberbank") {
      // Логика обработки webhook от Сбербанка
      console.log("Sberbank webhook processed")
    }

    // Обработка webhook от Тинькофф
    if (paymentSystem === "tinkoff") {
      // Логика обработки webhook от Тинькофф
      console.log("Tinkoff webhook processed")
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Webhook processing error:", error)
    return NextResponse.json({ success: false, error: "Ошибка обработки webhook" }, { status: 500 })
  }
}
