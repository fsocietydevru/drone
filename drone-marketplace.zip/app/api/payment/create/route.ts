import { type NextRequest, NextResponse } from "next/server"
import { createYooKassaPayment, createSberbankPayment, createTinkoffPayment, type PaymentData } from "@/lib/payment"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { paymentSystem, ...paymentData }: { paymentSystem: string } & PaymentData = body

    // Валидация данных
    if (!paymentData.amount || !paymentData.orderId || !paymentData.description) {
      return NextResponse.json({ success: false, error: "Недостаточно данных для создания платежа" }, { status: 400 })
    }

    let result

    switch (paymentSystem) {
      case "yookassa":
        result = await createYooKassaPayment(paymentData)
        break
      case "sberbank":
        result = await createSberbankPayment(paymentData)
        break
      case "tinkoff":
        result = await createTinkoffPayment(paymentData)
        break
      default:
        return NextResponse.json({ success: false, error: "Неподдерживаемая платежная система" }, { status: 400 })
    }

    // Сохраняем информацию о платеже в localStorage (в реальном проекте - в БД)
    if (result.success) {
      const paymentInfo = {
        id: result.paymentId,
        orderId: paymentData.orderId,
        amount: paymentData.amount,
        status: "pending",
        createdAt: new Date().toISOString(),
        paymentSystem,
      }

      // В реальном проекте здесь была бы запись в базу данных
      console.log("Payment created:", paymentInfo)
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Payment creation error:", error)
    return NextResponse.json({ success: false, error: "Внутренняя ошибка сервера" }, { status: 500 })
  }
}
