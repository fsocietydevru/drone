"use client"

import { useState, useEffect } from "react"
import { Search, ShoppingCart, Menu, Filter, Star, Heart, Zap, Shield, Truck } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PaymentModal } from "@/components/payment-modal"

// Получаем товары из localStorage или используем пустой массив
const getInitialDrones = () => {
  if (typeof window !== "undefined") {
    const saved = localStorage.getItem("drones")
    if (saved) {
      return JSON.parse(saved)
    }
  }
  // Возвращаем пустой массив вместо дефолтных товаров
  return []
}

const categories = ["Все", "Профессиональные", "Любительские", "Компактные", "Начинающие"]

export default function DronemarketplacePage() {
  const [selectedCategory, setSelectedCategory] = useState("Все")
  const [cartCount, setCartCount] = useState(0)
  const [drones, setDrones] = useState(getInitialDrones())
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [cartItems, setCartItems] = useState([])

  // Обновляем товары при изменении в localStorage
  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem("drones")
      if (saved) {
        setDrones(JSON.parse(saved))
      }
    }

    window.addEventListener("storage", handleStorageChange)

    // Проверяем изменения каждую секунду (для обновлений в той же вкладке)
    const interval = setInterval(() => {
      const saved = localStorage.getItem("drones")
      if (saved) {
        const newDrones = JSON.parse(saved)
        setDrones(newDrones)
      }
    }, 1000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      clearInterval(interval)
    }
  }, [])

  const filteredDrones =
    selectedCategory === "Все" ? drones : drones.filter((drone) => drone.category === selectedCategory)

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ru-RU").format(price) + " ₽"
  }

  const addToCart = (drone) => {
    const existingItem = cartItems.find((item) => item.id === drone.id)
    if (existingItem) {
      setCartItems(cartItems.map((item) => (item.id === drone.id ? { ...item, quantity: item.quantity + 1 } : item)))
    } else {
      setCartItems([...cartItems, { ...drone, quantity: 1 }])
    }
    setCartCount((prev) => prev + 1)
  }

  const openPaymentModal = () => {
    if (cartItems.length === 0) {
      alert("Корзина пуста")
      return
    }
    setShowPaymentModal(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-8">
              <Link
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"
              >
                DroneHub
              </Link>
              <nav className="hidden md:flex space-x-6">
                <Link href="#" className="text-slate-600 hover:text-blue-600 transition-colors font-medium">
                  Каталог
                </Link>
                <Link href="#" className="text-slate-600 hover:text-blue-600 transition-colors font-medium">
                  Поддержка
                </Link>
                <Link href="#" className="text-slate-600 hover:text-blue-600 transition-colors font-medium">
                  О нас
                </Link>
              </nav>
            </div>

            <div className="flex-1 max-w-xl mx-8 hidden md:block">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
                <Input
                  placeholder="Поиск дронов..."
                  className="pl-10 bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 rounded-xl shadow-sm"
                />
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-600 hover:text-red-500 hover:bg-red-50 rounded-xl"
              >
                <Heart className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-600 hover:text-blue-600 hover:bg-blue-50 relative rounded-xl"
                onClick={openPaymentModal}
              >
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center bg-gradient-to-r from-blue-500 to-purple-500 text-white border-2 border-white">
                    {cartCount}
                  </Badge>
                )}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-xl"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-pink-600/10"></div>
        <div className="container mx-auto px-4 text-center relative">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent leading-tight">
              Мир Дронов
            </h1>
            <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto leading-relaxed">
              Откройте для себя лучшие дроны от ведущих производителей. Профессиональная съемка, развлечения и многое
              другое.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Смотреть каталог
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-slate-300 text-slate-700 hover:bg-slate-50 rounded-xl shadow-sm hover:shadow-md transition-all duration-300"
              >
                Сравнить модели
              </Button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              <div className="flex items-center justify-center space-x-3 bg-white/60 backdrop-blur-sm rounded-2xl p-4 shadow-sm">
                <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-2 rounded-xl">
                  <Zap className="h-5 w-5 text-white" />
                </div>
                <span className="text-slate-700 font-medium">Быстрая доставка</span>
              </div>
              <div className="flex items-center justify-center space-x-3 bg-white/60 backdrop-blur-sm rounded-2xl p-4 shadow-sm">
                <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-2 rounded-xl">
                  <Shield className="h-5 w-5 text-white" />
                </div>
                <span className="text-slate-700 font-medium">Гарантия качества</span>
              </div>
              <div className="flex items-center justify-center space-x-3 bg-white/60 backdrop-blur-sm rounded-2xl p-4 shadow-sm">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 p-2 rounded-xl">
                  <Truck className="h-5 w-5 text-white" />
                </div>
                <span className="text-slate-700 font-medium">Бесплатная доставка</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-white/50 backdrop-blur-sm border-y border-slate-200">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={
                    selectedCategory === category
                      ? "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl shadow-md"
                      : "border-slate-300 text-slate-600 hover:bg-slate-50 rounded-xl"
                  }
                >
                  {category}
                </Button>
              ))}
            </div>
            <div className="flex gap-4 items-center">
              <Select>
                <SelectTrigger className="w-48 bg-white border-slate-200 text-slate-900 rounded-xl shadow-sm">
                  <SelectValue placeholder="Сортировка" />
                </SelectTrigger>
                <SelectContent className="bg-white border-slate-200 rounded-xl shadow-lg">
                  <SelectItem value="popular">По популярности</SelectItem>
                  <SelectItem value="price-low">Цена: по возрастанию</SelectItem>
                  <SelectItem value="price-high">Цена: по убыванию</SelectItem>
                  <SelectItem value="rating">По рейтингу</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="icon"
                className="border-slate-300 text-slate-600 hover:bg-slate-50 rounded-xl"
              >
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDrones.map((drone) => (
              <Card
                key={drone.id}
                className="bg-white border-slate-200 hover:border-blue-300 transition-all duration-300 group hover:shadow-xl rounded-2xl overflow-hidden"
              >
                <CardContent className="p-0">
                  <div className="relative overflow-hidden">
                    <Image
                      src={drone.image || "/placeholder.svg"}
                      alt={drone.name}
                      width={300}
                      height={300}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {drone.isNew && (
                      <Badge className="absolute top-3 left-3 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white rounded-xl">
                        Новинка
                      </Badge>
                    )}
                    {drone.discount > 0 && (
                      <Badge className="absolute top-3 right-3 bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white rounded-xl">
                        -{drone.discount}%
                      </Badge>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-3 right-12 bg-white/80 hover:bg-white text-slate-600 hover:text-red-500 rounded-xl backdrop-blur-sm"
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm text-slate-600 ml-1 font-medium">{drone.rating}</span>
                      </div>
                      <span className="text-sm text-slate-400">({drone.reviews})</span>
                    </div>

                    <h3 className="text-lg font-semibold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                      {drone.name}
                    </h3>

                    <div className="flex flex-wrap gap-1 mb-4">
                      {drone.features.map((feature, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="text-xs bg-slate-100 text-slate-600 rounded-lg"
                        >
                          {feature}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-slate-900">{formatPrice(drone.price)}</span>
                        {drone.originalPrice && (
                          <span className="text-sm text-slate-400 line-through">
                            {formatPrice(drone.originalPrice)}
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-slate-500">Осталось: {drone.stock}</div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
                        onClick={() => addToCart(drone)}
                        disabled={drone.stock === 0}
                      >
                        {drone.stock === 0 ? "Нет в наличии" : "В корзину"}
                      </Button>
                      <Button
                        variant="outline"
                        className="border-slate-300 text-slate-600 hover:bg-slate-50 rounded-xl"
                      >
                        Подробнее
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-slate-50 to-blue-50 border-t border-slate-200 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
                DroneHub
              </h3>
              <p className="text-slate-600 mb-4 leading-relaxed">
                Ваш надежный партнер в мире дронов и беспилотных технологий.
              </p>
            </div>

            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Каталог</h4>
              <ul className="space-y-2 text-slate-600">
                <li>
                  <Link href="#" className="hover:text-blue-600 transition-colors">
                    Профессиональные
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-blue-600 transition-colors">
                    Любительские
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-blue-600 transition-colors">
                    Компактные
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-blue-600 transition-colors">
                    Начинающие
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Поддержка</h4>
              <ul className="space-y-2 text-slate-600">
                <li>
                  <Link href="#" className="hover:text-blue-600 transition-colors">
                    Помощь
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-blue-600 transition-colors">
                    Доставка
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-blue-600 transition-colors">
                    Возврат
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-blue-600 transition-colors">
                    Гарантия
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Контакты</h4>
              <ul className="space-y-2 text-slate-600">
                <li>+7 (800) 123-45-67</li>
                <li>info@dronehub.ru</li>
                <li>Москва, ул. Примерная, 123</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-200 mt-8 pt-8 text-center text-slate-500">
            <p>&copy; 2024 DroneHub. Все права защищены.</p>
          </div>
        </div>
      </footer>
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        orderData={{
          items: cartItems,
          total: cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0),
        }}
      />
    </div>
  )
}
