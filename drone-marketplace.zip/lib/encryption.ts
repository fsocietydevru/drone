// Простое шифрование для localStorage (для демонстрации)
// В продакшене используйте более надежные методы

const SECRET_KEY = "drone-hub-secret-2024" // В продакшене должен быть в переменных окружения

// Простое XOR шифрование
function simpleEncrypt(text: string, key: string): string {
  let result = ""
  for (let i = 0; i < text.length; i++) {
    result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length))
  }
  return btoa(result) // Base64 кодирование
}

function simpleDecrypt(encryptedText: string, key: string): string {
  try {
    const decoded = atob(encryptedText) // Base64 декодирование
    let result = ""
    for (let i = 0; i < decoded.length; i++) {
      result += String.fromCharCode(decoded.charCodeAt(i) ^ key.charCodeAt(i % key.length))
    }
    return result
  } catch (error) {
    console.error("Decryption error:", error)
    return ""
  }
}

// Функции для работы с зашифрованными данными
export function setEncryptedItem(key: string, value: any): void {
  try {
    const jsonString = JSON.stringify(value)
    const encrypted = simpleEncrypt(jsonString, SECRET_KEY)
    localStorage.setItem(key, encrypted)
  } catch (error) {
    console.error("Encryption error:", error)
    // Fallback к обычному сохранению
    localStorage.setItem(key, JSON.stringify(value))
  }
}

export function getEncryptedItem(key: string): any {
  try {
    const encrypted = localStorage.getItem(key)
    if (!encrypted) return null

    // Проверяем, зашифрованы ли данные (Base64)
    if (isBase64(encrypted)) {
      const decrypted = simpleDecrypt(encrypted, SECRET_KEY)
      return decrypted ? JSON.parse(decrypted) : null
    } else {
      // Данные не зашифрованы, возвращаем как есть
      return JSON.parse(encrypted)
    }
  } catch (error) {
    console.error("Decryption error:", error)
    return null
  }
}

export function removeEncryptedItem(key: string): void {
  localStorage.removeItem(key)
}

// Проверка, является ли строка Base64
function isBase64(str: string): boolean {
  try {
    return btoa(atob(str)) === str
  } catch (err) {
    return false
  }
}

// Функция для миграции существующих данных
export function migrateToEncrypted(): void {
  const keysToMigrate = ["drones", "paymentConfig", "adminAuth"]

  keysToMigrate.forEach((key) => {
    const data = localStorage.getItem(key)
    if (data && !isBase64(data)) {
      try {
        const parsed = JSON.parse(data)
        setEncryptedItem(key, parsed)
        console.log(`Migrated ${key} to encrypted storage`)
      } catch (error) {
        console.error(`Failed to migrate ${key}:`, error)
      }
    }
  })
}

// Хеширование паролей (простая реализация)
export function hashPassword(password: string): string {
  let hash = 0
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Конвертируем в 32-битное число
  }
  return hash.toString(16)
}

// Проверка пароля
export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash
}
