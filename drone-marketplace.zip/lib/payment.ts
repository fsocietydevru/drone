import { getPaymentSystemConfig } from "./payment-config"

// Типы для платежей
export interface PaymentData {
  amount: number
  currency: string
  description: string
  orderId: string
  customerEmail?: string
  customerPhone?: string
  returnUrl: string
}

export interface PaymentResult {
  success: boolean
  paymentUrl?: string
  paymentId?: string
  error?: string
}

// YooKassa (Яндекс.Касса)
export async function createYooKassaPayment(data: PaymentData): Promise<PaymentResult> {
  const config = getPaymentSystemConfig("yookassa")
  if (!config || !config.enabled) {
    return { success: false, error: "ЮKassa не настроена или отключена" }
  }

  try {
    const response = await fetch(`${config.settings.apiUrl}/payments`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Idempotence-Key": `${data.orderId}-${Date.now()}`,
        Authorization: `Basic ${btoa(`${config.settings.shopId}:${config.settings.secretKey}`)}`,
      },
      body: JSON.stringify({
        amount: {
          value: (data.amount / 100).toFixed(2),
          currency: data.currency,
        },
        confirmation: {
          type: "redirect",
          return_url: data.returnUrl,
        },
        description: data.description,
        metadata: {
          order_id: data.orderId,
        },
        receipt: {
          customer: {
            email: data.customerEmail,
          },
          items: [
            {
              description: data.description,
              quantity: "1.00",
              amount: {
                value: (data.amount / 100).toFixed(2),
                currency: data.currency,
              },
              vat_code: 1,
            },
          ],
        },
      }),
    })

    const result = await response.json()

    if (response.ok) {
      return {
        success: true,
        paymentUrl: result.confirmation.confirmation_url,
        paymentId: result.id,
      }
    } else {
      return {
        success: false,
        error: result.description || "Ошибка создания платежа",
      }
    }
  } catch (error) {
    return {
      success: false,
      error: "Ошибка соединения с платежной системой",
    }
  }
}

// Сбербанк
export async function createSberbankPayment(data: PaymentData): Promise<PaymentResult> {
  const config = getPaymentSystemConfig("sberbank")
  if (!config || !config.enabled) {
    return { success: false, error: "Сбербанк не настроен или отключен" }
  }

  try {
    const params = new URLSearchParams({
      userName: config.settings.userName,
      password: config.settings.password,
      orderNumber: data.orderId,
      amount: data.amount.toString(),
      currency: data.currency === "RUB" ? "643" : "840",
      returnUrl: data.returnUrl,
      description: data.description,
    })

    const response = await fetch(`${config.settings.apiUrl}/register.do`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params,
    })

    const result = await response.json()

    if (result.errorCode === 0) {
      return {
        success: true,
        paymentUrl: result.formUrl,
        paymentId: result.orderId,
      }
    } else {
      return {
        success: false,
        error: result.errorMessage || "Ошибка создания платежа",
      }
    }
  } catch (error) {
    return {
      success: false,
      error: "Ошибка соединения с платежной системой",
    }
  }
}

// Тинькофф
export async function createTinkoffPayment(data: PaymentData): Promise<PaymentResult> {
  const config = getPaymentSystemConfig("tinkoff")
  if (!config || !config.enabled) {
    return { success: false, error: "Тинькофф не настроен или отключен" }
  }

  try {
    const requestData = {
      TerminalKey: config.settings.terminalKey,
      Amount: data.amount,
      OrderId: data.orderId,
      Description: data.description,
      DATA: {
        Email: data.customerEmail,
        Phone: data.customerPhone,
      },
      Receipt: {
        Email: data.customerEmail,
        Items: [
          {
            Name: data.description,
            Price: data.amount,
            Quantity: 1,
            Amount: data.amount,
            Tax: "vat10",
          },
        ],
      },
    }

    const response = await fetch(`${config.settings.apiUrl}/Init`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestData),
    })

    const result = await response.json()

    if (result.Success) {
      return {
        success: true,
        paymentUrl: result.PaymentURL,
        paymentId: result.PaymentId,
      }
    } else {
      return {
        success: false,
        error: result.Message || "Ошибка создания платежа",
      }
    }
  } catch (error) {
    return {
      success: false,
      error: "Ошибка соединения с платежной системой",
    }
  }
}
