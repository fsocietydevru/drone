import { setEncryptedItem, getEncryptedItem, removeEncryptedItem } from "./encryption"

// Безопасное хранение данных админ панели
export class SecureStorage {
  // Сохранение товаров
  static saveDrones(drones: any[]): void {
    setEncryptedItem("drones", drones)
  }

  // Загрузка товаров
  static loadDrones(): any[] {
    const data = getEncryptedItem("drones")
    return data || []
  }

  // Сохранение конфигурации платежей
  static savePaymentConfig(config: any[]): void {
    setEncryptedItem("paymentConfig", config)
  }

  // Загрузка конфигурации платежей
  static loadPaymentConfig(): any[] {
    const data = getEncryptedItem("paymentConfig")
    return data || []
  }

  // Сохранение состояния авторизации
  static setAuthStatus(isAuthenticated: boolean): void {
    setEncryptedItem("adminAuth", isAuthenticated ? "true" : "false")
  }

  // Проверка авторизации
  static getAuthStatus(): boolean {
    const data = getEncryptedItem("adminAuth")
    return data === "true"
  }

  // Удаление авторизации
  static clearAuth(): void {
    removeEncryptedItem("adminAuth")
  }

  // Сохранение настроек админа
  static saveAdminSettings(settings: any): void {
    setEncryptedItem("adminSettings", settings)
  }

  // Загрузка настроек админа
  static loadAdminSettings(): any {
    return getEncryptedItem("adminSettings") || {}
  }

  // Очистка всех данных
  static clearAll(): void {
    const keys = ["drones", "paymentConfig", "adminAuth", "adminSettings"]
    keys.forEach((key) => removeEncryptedItem(key))
  }

  // Экспорт данных (зашифрованный)
  static exportData(): string {
    const data = {
      drones: this.loadDrones(),
      paymentConfig: this.loadPaymentConfig(),
      adminSettings: this.loadAdminSettings(),
      exportDate: new Date().toISOString(),
    }
    return btoa(JSON.stringify(data))
  }

  // Импорт данных
  static importData(encryptedData: string): boolean {
    try {
      const data = JSON.parse(atob(encryptedData))

      if (data.drones) this.saveDrones(data.drones)
      if (data.paymentConfig) this.savePaymentConfig(data.paymentConfig)
      if (data.adminSettings) this.saveAdminSettings(data.adminSettings)

      return true
    } catch (error) {
      console.error("Import error:", error)
      return false
    }
  }
}
