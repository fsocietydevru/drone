// Типы для конфигурации платежных систем
export interface PaymentSystemConfig {
  id: string
  name: string
  enabled: boolean
  settings: {
    [key: string]: string
  }
  description: string
  icon: string
}

// Дефолтная конфигурация платежных систем
export const DEFAULT_PAYMENT_CONFIG: PaymentSystemConfig[] = [
  {
    id: "yookassa",
    name: "ЮKassa",
    enabled: true,
    settings: {
      shopId: process.env.YOOKASSA_SHOP_ID || "",
      secretKey: process.env.YOOKASSA_SECRET_KEY || "",
      apiUrl: "https://api.yookassa.ru/v3",
    },
    description: "Яндекс.Касса - банковские карты, электронные кошельки",
    icon: "CreditCard",
  },
  {
    id: "sberbank",
    name: "Сбербанк",
    enabled: false,
    settings: {
      userName: process.env.SBERBANK_USERNAME || "",
      password: process.env.SBERBANK_PASSWORD || "",
      apiUrl: "https://securepayments.sberbank.ru/payment/rest",
    },
    description: "Сбербанк Онлайн, банковские карты",
    icon: "Building2",
  },
  {
    id: "tinkoff",
    name: "Тинькофф",
    enabled: false,
    settings: {
      terminalKey: process.env.TINKOFF_TERMINAL_KEY || "",
      password: process.env.TINKOFF_PASSWORD || "",
      apiUrl: "https://securepay.tinkoff.ru/v2",
    },
    description: "Тинькофф Pay, банковские карты",
    icon: "Smartphone",
  },
]

// Получение конфигурации из localStorage или дефолтной
export function getPaymentConfig(): PaymentSystemConfig[] {
  if (typeof window !== "undefined") {
    const saved = localStorage.getItem("paymentConfig")
    if (saved) {
      try {
        return JSON.parse(saved)
      } catch (error) {
        console.error("Error parsing payment config:", error)
      }
    }
  }
  return DEFAULT_PAYMENT_CONFIG
}

// Сохранение конфигурации
export function savePaymentConfig(config: PaymentSystemConfig[]): void {
  if (typeof window !== "undefined") {
    localStorage.setItem("paymentConfig", JSON.stringify(config))
  }
}

// Получение активных платежных систем
export function getEnabledPaymentSystems(): PaymentSystemConfig[] {
  return getPaymentConfig().filter((system) => system.enabled)
}

// Получение конфигурации конкретной системы
export function getPaymentSystemConfig(systemId: string): PaymentSystemConfig | null {
  const config = getPaymentConfig()
  return config.find((system) => system.id === systemId) || null
}
