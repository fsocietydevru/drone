"use client"

import { useState, useEffect } from "react"
import { CreditCard, Smartphone, Building2, X, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { getEnabledPaymentSystems } from "@/lib/payment-config"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  orderData: {
    items: Array<{
      id: number
      name: string
      price: number
      quantity: number
    }>
    total: number
  }
}

export function PaymentModal({ isOpen, onClose, orderData }: PaymentModalProps) {
  const [enabledPaymentSystems, setEnabledPaymentSystems] = useState([])
  const [selectedPaymentSystem, setSelectedPaymentSystem] = useState("")
  const [customerData, setCustomerData] = useState({
    email: "",
    phone: "",
    name: "",
  })
  const [isProcessing, setIsProcessing] = useState(false)

  useEffect(() => {
    if (isOpen) {
      const systems = getEnabledPaymentSystems()
      setEnabledPaymentSystems(systems)
      if (systems.length > 0 && !selectedPaymentSystem) {
        setSelectedPaymentSystem(systems[0].id)
      }
    }
  }, [isOpen, selectedPaymentSystem])

  if (!isOpen) return null

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "CreditCard":
        return CreditCard
      case "Building2":
        return Building2
      case "Smartphone":
        return Smartphone
      default:
        return CreditCard
    }
  }

  const getIconColor = (systemId: string) => {
    switch (systemId) {
      case "yookassa":
        return "bg-purple-100 text-purple-700"
      case "sberbank":
        return "bg-green-100 text-green-700"
      case "tinkoff":
        return "bg-yellow-100 text-yellow-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("ru-RU").format(price) + " ₽"
  }

  const handlePayment = async () => {
    if (!customerData.email || !customerData.phone) {
      alert("Пожалуйста, заполните все обязательные поля")
      return
    }

    if (enabledPaymentSystems.length === 0) {
      alert("Нет доступных способов оплаты. Обратитесь к администратору.")
      return
    }

    setIsProcessing(true)

    try {
      const orderId = `ORDER-${Date.now()}`
      const paymentData = {
        paymentSystem: selectedPaymentSystem,
        amount: orderData.total * 100, // Сумма в копейках
        currency: "RUB",
        description: `Заказ ${orderId} - ${orderData.items.length} товар(ов)`,
        orderId,
        customerEmail: customerData.email,
        customerPhone: customerData.phone,
        returnUrl: `${window.location.origin}/payment/success?orderId=${orderId}`,
      }

      const response = await fetch("/api/payment/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(paymentData),
      })

      const result = await response.json()

      if (result.success && result.paymentUrl) {
        // Сохраняем информацию о заказе
        localStorage.setItem(
          `order-${orderId}`,
          JSON.stringify({
            ...orderData,
            customerData,
            paymentId: result.paymentId,
            status: "pending",
          }),
        )

        // Перенаправляем на страницу оплаты
        window.location.href = result.paymentUrl
      } else {
        alert(result.error || "Ошибка создания платежа")
      }
    } catch (error) {
      console.error("Payment error:", error)
      alert("Ошибка при создании платежа")
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-2xl bg-white rounded-2xl shadow-xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-900">Оформление заказа</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose} className="rounded-xl">
            <X className="h-5 w-5" />
          </Button>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Информация о заказе */}
          <div className="bg-slate-50 rounded-xl p-4">
            <h3 className="font-semibold text-slate-900 mb-3">Ваш заказ</h3>
            <div className="space-y-2">
              {orderData.items.map((item) => (
                <div key={item.id} className="flex justify-between items-center">
                  <span className="text-slate-600">
                    {item.name} × {item.quantity}
                  </span>
                  <span className="font-medium">{formatPrice(item.price * item.quantity)}</span>
                </div>
              ))}
              <div className="border-t pt-2 mt-2">
                <div className="flex justify-between items-center font-bold text-lg">
                  <span>Итого:</span>
                  <span className="text-blue-600">{formatPrice(orderData.total)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Контактные данные */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Контактные данные</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Имя</Label>
                <Input
                  id="name"
                  value={customerData.name}
                  onChange={(e) => setCustomerData({ ...customerData, name: e.target.value })}
                  className="rounded-xl"
                  placeholder="Ваше имя"
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={customerData.email}
                  onChange={(e) => setCustomerData({ ...customerData, email: e.target.value })}
                  className="rounded-xl"
                  placeholder="example@mail.ru"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="phone">Телефон *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={customerData.phone}
                  onChange={(e) => setCustomerData({ ...customerData, phone: e.target.value })}
                  className="rounded-xl"
                  placeholder="+7 (999) 123-45-67"
                  required
                />
              </div>
            </div>
          </div>

          {/* Выбор способа оплаты */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Способ оплаты</h3>
            {enabledPaymentSystems.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <p>Нет доступных способов оплаты</p>
                <p className="text-sm">Обратитесь к администратору</p>
              </div>
            ) : (
              <div className="grid gap-3">
                {enabledPaymentSystems.map((system) => {
                  const Icon = getIcon(system.icon)
                  return (
                    <div
                      key={system.id}
                      className={`border-2 rounded-xl p-4 cursor-pointer transition-all ${
                        selectedPaymentSystem === system.id
                          ? "border-blue-500 bg-blue-50"
                          : "border-slate-200 hover:border-slate-300"
                      }`}
                      onClick={() => setSelectedPaymentSystem(system.id)}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${getIconColor(system.id)}`}>
                          <Icon className="h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <div className="font-medium text-slate-900">{system.name}</div>
                          <div className="text-sm text-slate-500">{system.description}</div>
                        </div>
                        {selectedPaymentSystem === system.id && (
                          <Badge className="bg-blue-500 text-white">Выбрано</Badge>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          {/* Кнопка оплаты */}
          <div className="flex gap-3 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1 rounded-xl" disabled={isProcessing}>
              Отмена
            </Button>
            <Button
              onClick={handlePayment}
              className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl"
              disabled={isProcessing || enabledPaymentSystems.length === 0}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Обработка...
                </>
              ) : (
                `Оплатить ${formatPrice(orderData.total)}`
              )}
            </Button>
          </div>

          <div className="text-xs text-slate-500 text-center">
            Нажимая "Оплатить", вы соглашаетесь с условиями использования и политикой конфиденциальности
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
